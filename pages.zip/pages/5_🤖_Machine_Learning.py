import streamlit as st
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.preprocessing import PolynomialFeatures, StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score, accuracy_score, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt






st.set_page_config(page_title="Automated Data Analyzer", page_icon="📊", layout="wide")

def machine_learning_page():
    st.title("🤖 Basic Machine Learning Models")

    if 'df' in st.session_state and st.session_state['df'] is not None:
        df = st.session_state['df'].copy()

        numeric_cols = df.select_dtypes(include=np.number).columns.tolist()
        categorical_cols = df.select_dtypes(include=['object', 'category', 'bool']).columns.tolist()

        model_type = st.selectbox("Choose Model Type", ["---", "Regression", "Classification"])

        # -------------------- REGRESSION MODELS --------------------
        if model_type == "Regression":
            reg_model = st.selectbox("Choose Regression Model", ["Linear Regression", "Polynomial Regression"])

            if len(numeric_cols) < 2:
                st.warning("⚠ Not enough numeric columns for regression.")
            else:
                target_col = st.selectbox("Select Target Variable (Numeric)", numeric_cols, key="reg_target")
                feature_cols = st.multiselect("Select Feature Variables (Numeric)", [col for col in numeric_cols if col != target_col], key="reg_features")

                if target_col and feature_cols:
                    df_model = df[[target_col] + feature_cols].dropna()
                    if df_model.empty:
                        st.warning("⚠ No complete rows available after dropping NaNs.")
                        return

                    X = df_model[feature_cols]
                    y = df_model[target_col]

                    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

                    if reg_model == "Linear Regression":
                        model = LinearRegression()
                    elif reg_model == "Polynomial Regression":
                        degree = st.slider("Select Polynomial Degree", 2, 5, 2)
                        model = make_pipeline(PolynomialFeatures(degree), LinearRegression())

                    model.fit(X_train, y_train)
                    y_pred = model.predict(X_test)

                    st.write("##### Model Performance")
                    st.write(f"MSE: {mean_squared_error(y_test, y_pred):.2f}")
                    st.write(f"R²: {r2_score(y_test, y_pred):.2f}")

                    if len(feature_cols) == 1:
                        st.write("##### Regression Plot")
                        fig, ax = plt.subplots(figsize=(10, 6))
                        sns.scatterplot(x=X_test[feature_cols[0]], y=y_test, ax=ax, label="Actual")
                        sns.scatterplot(x=X_test[feature_cols[0]], y=y_pred, ax=ax, color='red', label="Predicted")
                        ax.set_title(f"{reg_model} for {feature_cols[0]} vs {target_col}")
                        ax.legend()
                        st.pyplot(fig)
                        plt.close(fig)

        # -------------------- CLASSIFICATION MODELS --------------------
        elif model_type == "Classification":
            class_model = st.selectbox("Choose Classification Model", [
                "Logistic Regression", "k-Nearest Neighbors (kNN)", "Support Vector Machine (SVM)",
                "Decision Tree", "Random Forest", "Naive Bayes", "Neural Network"
            ])

            possible_targets = [col for col in categorical_cols if df[col].nunique() == 2]

            if not possible_targets:
                st.warning("⚠ No suitable binary categorical target found.")
                return

            target_col = st.selectbox("Select Target Variable (Binary Categorical)", possible_targets, key="class_target")
            feature_cols = st.multiselect("Select Feature Variables (Numeric)", numeric_cols, key="class_features")

            if target_col and feature_cols:
                df_model = df[[target_col] + feature_cols].dropna()
                if df_model.empty:
                    st.warning("⚠ No complete rows available.")
                    return

                X = df_model[feature_cols]
                y = df_model[target_col]

                if y.dtype == 'object' or y.dtype == 'category':
                    unique_vals = y.unique()
                    mapping = {unique_vals[0]: 0, unique_vals[1]: 1}
                    y = y.map(mapping)

                X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

                # Select classifier
                if class_model == "Logistic Regression":
                    model = LogisticRegression(max_iter=1000)
                elif class_model == "k-Nearest Neighbors (kNN)":
                    k = st.slider("Select number of neighbors (k)", 1, 15, 5)
                    model = KNeighborsClassifier(n_neighbors=k)
                elif class_model == "Support Vector Machine (SVM)":
                    model = SVC(probability=True)
                elif class_model == "Decision Tree":
                    model = DecisionTreeClassifier()
                elif class_model == "Random Forest":
                    model = RandomForestClassifier()
                elif class_model == "Naive Bayes":
                    model = GaussianNB()
                elif class_model == "Neural Network":
                    model = MLPClassifier(max_iter=1000)

                model.fit(X_train, y_train)
                y_pred = model.predict(X_test)

                st.write("##### Model Performance")
                st.write(f"Accuracy: {accuracy_score(y_test, y_pred):.2f}")

                st.write("##### Confusion Matrix")
                cm = confusion_matrix(y_test, y_pred)
                st.dataframe(pd.DataFrame(cm, index=['Actual 0', 'Actual 1'], columns=['Predicted 0', 'Predicted 1']))

        else:
            st.info("Select a model type (Regression or Classification) to proceed.")

    else:
        st.warning("⚠ Please upload a dataset first.")
# --- Custom CSS (wrapped as string) ---
custom_style = """
<style>
/* App background */
[data-testid="stAppViewContainer"] {
    background: linear-gradient(135deg, #1f1f2e, #2d2d44);
    color: #f5f5f5;
}

/* Header */
[data-testid="stHeader"] {
    background: rgba(32, 201, 151, 0.9);
    color: white;
}

/* Sidebar */
[data-testid="stSidebar"] {
    background: rgba(20, 20, 35, 0.95);
    color: #f5f5f5;
}
[data-testid="stSidebar"] * {
    color: #f5f5f5 !important;
}

/* Titles */
h1, h2, h3, h4, h5, h6 {
    color: #20c997;
    text-shadow: 1px 1px 4px rgba(0,0,0,0.6);
}
p, label, span {
    color: #e0e0e0 !important;
}

/* Navbar */
.navbar {
    display: flex;
    justify-content: center;
    background-color: #141422;
    padding: 12px;
    border-radius: 8px;
    margin-bottom: 25px;
}
.navbar a {
    text-decoration: none;
    margin: 0 20px;
    font-weight: bold;
    color: #f5f5f5;
    padding: 6px 12px;
    border-radius: 5px;
    transition: 0.3s;
}
.navbar a:hover {
    background-color: #20c997;
    color: white;
}

/* Buttons */
.stButton > button {
    background-color: #20c997;
    color: white;
    border-radius: 8px;
    font-weight: 600;
    padding: 8px 20px;
    border: none;
    transition: 0.3s;
    box-shadow: 2px 2px 6px rgba(0,0,0,0.4);
}
.stButton > button:hover {
    background-color: #ff6f61;
    transform: scale(1.05);
}
</style>
"""
st.markdown(custom_style, unsafe_allow_html=True)


machine_learning_page()