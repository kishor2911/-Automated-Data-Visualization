import streamlit as st
import pandas as pd
import numpy as np

st.set_page_config(page_title="Automated Data Analyzer", page_icon="📊", layout="wide")

# --- Data Cleaning Function ---
def data_cleaning_page():
    """Renders the Data Cleaning & Preprocessing page."""
    st.title("🧹 Data Cleaning & Preprocessing")
    
    if 'df' in st.session_state and st.session_state['df'] is not None:
        df = st.session_state['df'].copy()
        st.subheader("Original Data Preview")
        st.dataframe(df.head(), use_container_width=True)

        st.markdown("---")
        
        st.subheader("❌ Missing Values")
        missing_count = df.isnull().sum()
        missing_df = pd.DataFrame({'Column': missing_count.index, 'Missing Count': missing_count.values})
        st.dataframe(missing_df, use_container_width=True)
        
        option = st.selectbox(
            'How would you like to handle missing values?',
            ('Do Nothing', 'Remove rows with any missing values', 'Fill missing values')
        )

        if option == 'Remove rows with any missing values':
            df_cleaned = df.dropna()
            st.success(f"✅ Removed {len(df) - len(df_cleaned)} rows with missing values.")
            df = df_cleaned
        
        elif option == 'Fill missing values':
            fill_method = st.radio("Choose a fill method:", ("Fill with mean", "Fill with median", "Fill with mode"))
            
            numeric_cols = df.select_dtypes(include=np.number).columns
            categorical_cols = df.select_dtypes(include='object').columns
            
            df_filled = df.copy()
            if fill_method == 'Fill with mean' and len(numeric_cols) > 0:
                for col in numeric_cols:
                    df_filled[col] = df_filled[col].fillna(df_filled[col].mean())
                st.success("✅ Filled numeric missing values with the mean.")
            
            elif fill_method == 'Fill with median' and len(numeric_cols) > 0:
                for col in numeric_cols:
                    df_filled[col] = df_filled[col].fillna(df_filled[col].median())
                st.success("✅ Filled numeric missing values with the median.")
            
            elif fill_method == 'Fill with mode' and len(categorical_cols) > 0:
                for col in categorical_cols:
                    df_filled[col] = df_filled[col].fillna(df_filled[col].mode()[0])
                st.success("✅ Filled categorical missing values with the mode.")
            
            df = df_filled
        
        st.markdown("---")

        st.subheader("📋 Duplicate Rows")
        duplicate_count = df.duplicated().sum()
        st.info(f"There are {duplicate_count} duplicate rows in the dataset.")
        
        if st.button("Remove Duplicates"):
            df_no_duplicates = df.drop_duplicates()
            st.success(f"✅ Removed {len(df) - len(df_no_duplicates)} duplicate rows.")
            df = df_no_duplicates

        st.markdown("---")
        st.subheader("Cleaned Data Preview")
        st.dataframe(df.head(), use_container_width=True)
        
        st.session_state['df'] = df

        csv = df.to_csv(index=False).encode('utf-8')
        st.download_button(
            label="Download Cleaned Data as CSV",
            data=csv,
            file_name='cleaned_data.csv',
            mime='text/csv',
        )
    else:
        st.warning("⚠️ Please upload a dataset or select an example dataset on the 'Data Upload & Overview' page first.")

# --- Custom CSS (wrapped as string) ---
custom_style = """
<style>
/* App background */
[data-testid="stAppViewContainer"] {
    background: linear-gradient(135deg, #1f1f2e, #2d2d44);
    color: #f5f5f5;
}

/* Header */
[data-testid="stHeader"] {
    background: rgba(32, 201, 151, 0.9);
    color: white;
}

/* Sidebar */
[data-testid="stSidebar"] {
    background: rgba(20, 20, 35, 0.95);
    color: #f5f5f5;
}
[data-testid="stSidebar"] * {
    color: #f5f5f5 !important;
}

/* Titles */
h1, h2, h3, h4, h5, h6 {
    color: #20c997;
    text-shadow: 1px 1px 4px rgba(0,0,0,0.6);
}
p, label, span {
    color: #e0e0e0 !important;
}

/* Navbar */
.navbar {
    display: flex;
    justify-content: center;
    background-color: #141422;
    padding: 12px;
    border-radius: 8px;
    margin-bottom: 25px;
}
.navbar a {
    text-decoration: none;
    margin: 0 20px;
    font-weight: bold;
    color: #f5f5f5;
    padding: 6px 12px;
    border-radius: 5px;
    transition: 0.3s;
}
.navbar a:hover {
    background-color: #20c997;
    color: white;
}

/* Buttons */
.stButton > button {
    background-color: #20c997;
    color: white;
    border-radius: 8px;
    font-weight: 600;
    padding: 8px 20px;
    border: none;
    transition: 0.3s;
    box-shadow: 2px 2px 6px rgba(0,0,0,0.4);
}
.stButton > button:hover {
    background-color: #ff6f61;
    transform: scale(1.05);
}
</style>
"""
st.markdown(custom_style, unsafe_allow_html=True)



# --- Call Page ---
data_cleaning_page()
