import streamlit as st
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt




st.set_page_config(page_title="Automated Data Analyzer", page_icon="📊", layout="wide")
def advanced_analysis_page():
    """Renders the Advanced Analysis page."""
    st.title("🔬 Advanced Data Analysis")

    if 'df' in st.session_state and st.session_state['df'] is not None:
        df = st.session_state['df']

        st.markdown("---")
        st.subheader("Individual Column Analysis (Univariate)")
        selected_column_for_univariate = st.selectbox("Select a column for detailed analysis", df.columns)

        if selected_column_for_univariate:
            col_data = df[selected_column_for_univariate]
            st.write(f"#### Analysis for: `{selected_column_for_univariate}`")

            if pd.api.types.is_numeric_dtype(col_data):
                st.write("##### Numeric Column Statistics:")
                st.dataframe(col_data.describe())
                
                fig, ax = plt.subplots(figsize=(4, 3))
                sns.histplot(col_data, kde=True, color="purple", ax=ax)
                ax.set_title(f"Distribution of {selected_column_for_univariate}")
                st.pyplot(fig)
                plt.close(fig)

                fig, ax = plt.subplots(figsize=(7, 2))
                sns.boxplot(x=col_data, color="orange", ax=ax)
                ax.set_title(f"Box Plot for {selected_column_for_univariate}")
                st.pyplot(fig)
                plt.close(fig)

                st.markdown("---")
                st.subheader("Outlier Detection (Z-score Method)")
                
                if st.checkbox(f"Show outliers for {selected_column_for_univariate}"):
                    mean = col_data.mean()
                    std = col_data.std()
                    z_scores = np.abs((col_data - mean) / std)
                    threshold = st.slider("Z-score Threshold", min_value=1.0, max_value=5.0, value=3.0, step=0.1)
                    
                    outliers = df[z_scores > threshold]

                    if not outliers.empty:
                        st.warning(f"Found {len(outliers)} outliers (Z-score > {threshold}):")
                        st.dataframe(outliers)
                    else:
                        st.info("No significant outliers found with the selected threshold.")

            elif pd.api.types.is_categorical_dtype(col_data) or pd.api.types.is_object_dtype(col_data):
                st.write("##### Categorical Column Statistics:")
                st.write("Unique Values and Counts:")
                st.dataframe(col_data.value_counts())
                st.write("Value Frequencies (%):")
                st.dataframe(col_data.value_counts(normalize=True).mul(100).round(2).astype(str) + '%')

                fig, ax = plt.subplots(figsize=(7, 6))
                sns.countplot(y=col_data, order=col_data.value_counts().index, palette="tab10", ax=ax)
                ax.set_title(f"Frequency of {selected_column_for_univariate}")
                st.pyplot(fig)
                plt.close(fig)
            else:
                st.info("Column type not typically analyzed with these methods (e.g., boolean, datetime).")

        st.markdown("---")
        st.subheader("Categorical vs. Numeric Analysis")
        st.write("Explore relationships between one categorical and one numeric column.")

        categorical_cols = df.select_dtypes(include=['object', 'category', 'bool']).columns.tolist()
        numeric_cols = df.select_dtypes(include=np.number).columns.tolist()

        if len(categorical_cols) > 0 and len(numeric_cols) > 0:
            cat_col = st.selectbox("Select Categorical Column", categorical_cols, key="cat_num_cat_col")
            num_col = st.selectbox("Select Numeric Column", numeric_cols, key="cat_num_num_col")

            if cat_col and num_col:
                st.write(f"##### {num_col} by {cat_col} (Mean)")
                mean_by_cat = df.groupby(cat_col)[num_col].mean().reset_index()
                st.dataframe(mean_by_cat)

                fig, ax = plt.subplots(figsize=(7, 6))
                sns.barplot(x=mean_by_cat[cat_col], y=mean_by_cat[num_col], palette="mako", ax=ax)
                ax.set_title(f"Mean of {num_col} by {cat_col}", fontsize=16)
                plt.xticks(rotation=45, ha='right')
                st.pyplot(fig)
                plt.close(fig)

                st.write(f"##### Distribution of {num_col} across {cat_col} (Box Plot)")
                fig, ax = plt.subplots(figsize=(7, 6))
                sns.boxplot(x=df[cat_col], y=df[num_col], palette="viridis", ax=ax)
                ax.set_title(f"Distribution of {num_col} by {cat_col}", fontsize=16)
                plt.xticks(rotation=45, ha='right')
                st.pyplot(fig)
                plt.close(fig)
        else:
            st.info("Requires at least one categorical and one numeric column for this analysis.")
    else:
        st.warning("⚠️ Please upload a dataset or select an example dataset on the 'Data Upload & Overview' page first.")
# --- Custom CSS (wrapped as string) ---
custom_style = """
<style>
/* App background */
[data-testid="stAppViewContainer"] {
    background: linear-gradient(135deg, #1f1f2e, #2d2d44);
    color: #f5f5f5;
}

/* Header */
[data-testid="stHeader"] {
    background: rgba(32, 201, 151, 0.9);
    color: white;
}

/* Sidebar */
[data-testid="stSidebar"] {
    background: rgba(20, 20, 35, 0.95);
    color: #f5f5f5;
}
[data-testid="stSidebar"] * {
    color: #f5f5f5 !important;
}

/* Titles */
h1, h2, h3, h4, h5, h6 {
    color: #20c997;
    text-shadow: 1px 1px 4px rgba(0,0,0,0.6);
}
p, label, span {
    color: #e0e0e0 !important;
}

/* Navbar */
.navbar {
    display: flex;
    justify-content: center;
    background-color: #141422;
    padding: 12px;
    border-radius: 8px;
    margin-bottom: 25px;
}
.navbar a {
    text-decoration: none;
    margin: 0 20px;
    font-weight: bold;
    color: #f5f5f5;
    padding: 6px 12px;
    border-radius: 5px;
    transition: 0.3s;
}
.navbar a:hover {
    background-color: #20c997;
    color: white;
}

/* Buttons */
.stButton > button {
    background-color: #20c997;
    color: white;
    border-radius: 8px;
    font-weight: 600;
    padding: 8px 20px;
    border: none;
    transition: 0.3s;
    box-shadow: 2px 2px 6px rgba(0,0,0,0.4);
}
.stButton > button:hover {
    background-color: #ff6f61;
    transform: scale(1.05);
}
</style>
"""
st.markdown(custom_style, unsafe_allow_html=True)


advanced_analysis_page()