import streamlit as st
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import plotly.express as px
import io


st.set_page_config(page_title="Automated Data Analyzer", page_icon="📊", layout="wide")

def download_plot_button(fig, filename):
    """Helper function to create a download button for Matplotlib figures."""
    if fig is not None:
        buf = io.BytesIO()
        fig.savefig(buf, format="png", bbox_inches='tight')
        st.download_button(
            label="Download Plot as PNG",
            data=buf.getvalue(),
            file_name=filename,
            mime="image/png"
        )

def data_visualization_page():
    """Renders the Data Visualization page with various plot types."""
    st.title("📊 Data Visualization")

    if 'df' in st.session_state and st.session_state['df'] is not None:
        df = st.session_state['df']
        
        graph_type = st.selectbox(
            "Choose a Graph Type",
            ["---", "Line Plot", "Bar Plot", "Count Plot", "Histogram", "Box Plot", "Scatter Plot", "Heatmap", "Pair Plot", "Violin Plot", "Pie Chart"]
        )

        plot_options_container = st.container()
        
        sns.set_style("darkgrid")
        palette = sns.color_palette("Set1")

        if graph_type == "---":
            st.info("Select a graph type to get started!")

        elif graph_type in ["Line Plot", "Bar Plot", "Scatter Plot"]:
            with plot_options_container:
                x_col = st.selectbox("Select X-axis Column", df.columns)
                y_col = st.selectbox("Select Y-axis Column", df.columns)
                
                if graph_type == "Scatter Plot" and not (pd.api.types.is_numeric_dtype(df[x_col]) and pd.api.types.is_numeric_dtype(df[y_col])):
                    st.warning("⚠️ Scatter Plot requires numeric columns for both X and Y axes.")
                else:
                    fig, ax = plt.subplots(figsize=(10, 7))
                    try:
                        if graph_type == "Line Plot":
                            sns.lineplot(x=df[x_col], y=df[y_col], marker="o", color=palette[0], ax=ax)
                            ax.set_title(f"📈 Line Plot: {x_col} vs {y_col}", fontsize=16)
                        
                        elif graph_type == "Bar Plot":
                            sns.barplot(x=df[x_col], y=df[y_col], palette=palette, ax=ax)
                            ax.set_title(f"📊 Bar Plot: {x_col} vs {y_col}", fontsize=16)
                            plt.xticks(rotation=45, ha='right')

                        elif graph_type == "Scatter Plot":
                            sns.scatterplot(x=df[x_col], y=df[y_col], color=palette[4], s=80, ax=ax)
                            ax.set_title(f"⚡ Scatter Plot: {x_col} vs {y_col}", fontsize=16)
                        
                        st.pyplot(fig)
                        download_plot_button(fig, f"{graph_type.lower().replace(' ', '_')}.png")
                        plt.close(fig)
                    except Exception as e:
                        st.error(f"❌ An error occurred while plotting: {e}")

        elif graph_type == "Histogram":
            with plot_options_container:
                numeric_cols = df.select_dtypes(include=np.number).columns
                if len(numeric_cols) > 0:
                    col = st.selectbox("Select Numeric Column", numeric_cols)
                    fig, ax = plt.subplots(figsize=(10, 7))
                    sns.histplot(df[col], bins=15, kde=True, color="skyblue", ax=ax)
                    ax.set_title(f"📉 Histogram: Distribution of {col}", fontsize=16)
                    st.pyplot(fig)
                    download_plot_button(fig, "histogram.png")
                    plt.close(fig)
                else:
                    st.warning("⚠️ No numeric columns found for a Histogram.")

        elif graph_type == "Box Plot":
            with plot_options_container:
                all_cols = df.columns.tolist()
                y_col_options = df.select_dtypes(include=np.number).columns.tolist()
                
                if len(y_col_options) > 0:
                    x_col = st.selectbox("Select X-axis Column (Optional, for categories)", ["None"] + all_cols)
                    y_col = st.selectbox("Select Y-axis Column (Numeric)", y_col_options)
                    
                    fig, ax = plt.subplots(figsize=(10, 7))
                    try:
                        if x_col != "None":
                            sns.boxplot(x=df[x_col], y=df[y_col], palette="pastel", ax=ax)
                            ax.set_title(f"📦 Box Plot: {y_col} by {x_col}", fontsize=16)
                            plt.xticks(rotation=45, ha='right')
                        else:
                            sns.boxplot(y=df[y_col], color="lightgreen", ax=ax)
                            ax.set_title(f"📦 Box Plot: Distribution of {y_col}", fontsize=16)
                        st.pyplot(fig)
                        download_plot_button(fig, "boxplot.png")
                        plt.close(fig)
                    except Exception as e:
                        st.error(f"❌ Error creating Box Plot. Ensure X-axis is categorical/none and Y-axis is numeric: {e}")
                else:
                    st.warning("⚠️ Box Plot requires at least one numeric column for the Y-axis.")

        elif graph_type == "Count Plot":
            with plot_options_container:
                categorical_cols = df.select_dtypes(include=['object', 'category', 'bool']).columns.tolist()
                if len(categorical_cols) > 0:
                    col = st.selectbox("Select Categorical Column", categorical_cols)
                    fig, ax = plt.subplots(figsize=(10, 7))
                    sns.countplot(x=df[col], palette="viridis", ax=ax)
                    ax.set_title(f"📊 Count Plot: Counts for {col}", fontsize=16)
                    plt.xticks(rotation=45, ha='right')
                    st.pyplot(fig)
                    download_plot_button(fig, "countplot.png")
                    plt.close(fig)
                else:
                    st.warning("⚠️ No categorical columns found for a Count Plot.")

        elif graph_type == "Heatmap":
            with plot_options_container:
                numeric_df = df.select_dtypes(include=np.number)
                if not numeric_df.empty and len(numeric_df.columns) > 1:
                    st.info("This heatmap shows the correlation between numeric columns.")
                    fig, ax = plt.subplots(figsize=(12, 10))
                    corr_matrix = numeric_df.corr()
                    sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', fmt=".2f", linewidths=.5, ax=ax, cbar_kws={'label': 'Correlation Coefficient'})
                    ax.set_title("🔥 Correlation Heatmap", fontsize=18)
                    st.pyplot(fig)
                    download_plot_button(fig, "heatmap.png")
                    plt.close(fig)
                else:
                    st.warning("⚠️ Heatmap requires at least two numeric columns to show correlations.")
        
        elif graph_type == "Pair Plot":
            with plot_options_container:
                numeric_df = df.select_dtypes(include=np.number)
                if not numeric_df.empty and len(numeric_df.columns) > 1:
                    st.info("Generating a Pair Plot. This may take a moment for large datasets or many columns.")
                    with st.spinner("Drawing Pair Plot..."):
                        try:
                            if len(numeric_df.columns) > 7:
                                st.warning("Too many numeric columns for an effective Pair Plot. Showing first 7.")
                                fig = sns.pairplot(numeric_df.iloc[:, :7])
                            else:
                                fig = sns.pairplot(numeric_df)
                            st.pyplot(fig)
                            download_plot_button(fig, "pairplot.png")
                            plt.close(fig)
                        except Exception as e:
                            st.error(f"❌ Error generating pair plot: {e}")
                else:
                    st.warning("⚠️ Pair Plot requires at least two numeric columns.")

        elif graph_type == "Violin Plot":
            with plot_options_container:
                all_cols = df.columns.tolist()
                y_col_options = df.select_dtypes(include=np.number).columns.tolist()

                if len(y_col_options) > 0:
                    x_col = st.selectbox("Select X-axis Column (Categorical)", ["None"] + all_cols)
                    y_col = st.selectbox("Select Y-axis Column (Numeric)", y_col_options)

                    if pd.api.types.is_numeric_dtype(df[y_col]):
                        fig, ax = plt.subplots(figsize=(10, 7))
                        try:
                            if x_col != "None":
                                sns.violinplot(x=df[x_col], y=df[y_col], palette="coolwarm", ax=ax)
                                ax.set_title(f"🎻 Violin Plot: Distribution of {y_col} by {x_col}", fontsize=16)
                                plt.xticks(rotation=45, ha='right')
                            else:
                                sns.violinplot(y=df[y_col], color="lightcoral", ax=ax)
                                ax.set_title(f"🎻 Violin Plot: Distribution of {y_col}", fontsize=16)
                            st.pyplot(fig)
                            download_plot_button(fig, "violinplot.png")
                            plt.close(fig)
                        except Exception as e:
                            st.error(f"❌ Error creating Violin Plot. Ensure X-axis is categorical/none and Y-axis is numeric: {e}")
                    else:
                        st.warning("⚠️ Violin Plot requires a numeric column for the Y-axis.")
                else:
                    st.warning("⚠️ Violin Plot requires at least one numeric column.")
        
        elif graph_type == "Pie Chart":
            with plot_options_container:
                categorical_cols = df.select_dtypes(include=['object', 'category', 'bool']).columns.tolist()
                if len(categorical_cols) > 0:
                    col = st.selectbox("Select Categorical Column for Pie Chart", categorical_cols)
                    
                    value_counts = df[col].value_counts()
                    if not value_counts.empty:
                        fig_plotly = px.pie(
                            values=value_counts.values, 
                            names=value_counts.index, 
                            title=f"Distribution of {col}",
                            hole=0.3
                        )
                        st.plotly_chart(fig_plotly, use_container_width=True)
                    else:
                        st.warning(f"⚠️ Column '{col}' has no data to plot a Pie Chart.")
                else:
                    st.warning("⚠️ Pie Chart requires a categorical column.")

    else:
        st.warning("⚠️ Please upload a dataset or select an example dataset on the 'Data Upload & Overview' page first.")
        
# --- Custom CSS (wrapped as string) ---
custom_style = """
<style>
/* App background */
[data-testid="stAppViewContainer"] {
    background: linear-gradient(135deg, #1f1f2e, #2d2d44);
    color: #f5f5f5;
}

/* Header */
[data-testid="stHeader"] {
    background: rgba(32, 201, 151, 0.9);
    color: white;
}

/* Sidebar */
[data-testid="stSidebar"] {
    background: rgba(20, 20, 35, 0.95);
    color: #f5f5f5;
}
[data-testid="stSidebar"] * {
    color: #f5f5f5 !important;
}

/* Titles */
h1, h2, h3, h4, h5, h6 {
    color: #20c997;
    text-shadow: 1px 1px 4px rgba(0,0,0,0.6);
}
p, label, span {
    color: #e0e0e0 !important;
}

/* Navbar */
.navbar {
    display: flex;
    justify-content: center;
    background-color: #141422;
    padding: 12px;
    border-radius: 8px;
    margin-bottom: 25px;
}
.navbar a {
    text-decoration: none;
    margin: 0 20px;
    font-weight: bold;
    color: #f5f5f5;
    padding: 6px 12px;
    border-radius: 5px;
    transition: 0.3s;
}
.navbar a:hover {
    background-color: #20c997;
    color: white;
}

/* Buttons */
.stButton > button {
    background-color: #20c997;
    color: white;
    border-radius: 8px;
    font-weight: 600;
    padding: 8px 20px;
    border: none;
    transition: 0.3s;
    box-shadow: 2px 2px 6px rgba(0,0,0,0.4);
}
.stButton > button:hover {
    background-color: #ff6f61;
    transform: scale(1.05);
}
</style>
"""
st.markdown(custom_style, unsafe_allow_html=True)


data_visualization_page()